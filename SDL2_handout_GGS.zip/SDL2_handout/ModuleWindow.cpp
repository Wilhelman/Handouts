#include "Globals.h"
#include "Application.h"
#include "ModuleWindow.h"
#include "SDL/include/SDL.h"

bool ModuleWindow::Init() {

	if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
		LOG("SDL_Init failed: %s\n", SDL_GetError());
		return false;
	}

	SDL_Window* window = NULL;
	SDL_Surface *screen = NULL;

	window = SDL_CreateWindow("Game_SDL_TEST", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, FULLSCREEN);
	if (window == NULL) {
		LOG("Could not create window: %s\n", SDL_GetError());
		return false;
	}

	screen = SDL_GetWindowSurface(window);
	if (screen == NULL) {
		LOG("Could not create the surface: %s\n", SDL_GetError());
		return false;
	}

	LOG("SDL_Init OK");
	return true;
}


bool ModuleWindow::CleanUp() {
	SDL_Quit();
	return true;
}

// TODO 2: Init the library and check for possible error
// using SDL_GetError()

// TODO 3: pick the width and height and experiment with flags: borderless / fullscreen / resizable,
// then create the window and check for errors

// TODO 4: Finally create a screen surface and keep it as a public variable

// TODO 5: Fill with code CleanUp() method :)

