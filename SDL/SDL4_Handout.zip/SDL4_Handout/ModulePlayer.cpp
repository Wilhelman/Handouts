#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModulePlayer::ModulePlayer()
{
	position.x = 100;
	position.y = 220;

	// idle animation (arcade sprite sheet)
	idle.PushBack({ 7, 14, 60, 90 });
	idle.PushBack({ 95, 15, 60, 89 });
	idle.PushBack({ 184, 14, 60, 90 });
	idle.PushBack({ 276, 11, 60, 93 });
	idle.PushBack({ 366, 12, 60, 92 });
	idle.speed = 0.2f;

	// walk forward animation (arcade sprite sheet)
	//forward.frames.PushBack({9, 136, 53, 83});
	forward.PushBack({ 78, 131, 60, 88 });
	forward.PushBack({ 162, 128, 64, 92 });
	forward.PushBack({ 259, 128, 63, 90 });
	forward.PushBack({ 352, 128, 54, 91 });
	forward.PushBack({ 432, 131, 50, 89 });
	forward.speed = 0.1f;

	backward.PushBack({ 542, 128, 60, 88 });
	backward.PushBack({ 628, 128, 64, 92 });
	backward.PushBack({ 712, 128, 63, 90 });
	backward.PushBack({ 796, 128, 74, 96 });
	backward.PushBack({ 882, 125, 59, 96 });
	backward.PushBack({ 974, 128, 54, 91 });
	backward.speed = 0.1f;

	//kick
	kick.PushBack({ 596, 265, 70, 98 });
	kick.PushBack({ 685, 263, 70, 96 });
	kick.PushBack({ 771, 256, 120, 103 });
	kick.speed = 0.1f;

	//punch
	punch.PushBack({ 252, 269, 60, 94 });
	punch.PushBack({ 330, 266, 82, 102 });
	punch.PushBack({ 421, 261, 121, 110 });
	punch.speed = 0.1f;

	//jump
	jump.PushBack({ 17, 847, 55, 85 });
	jump.PushBack({ 100, 823, 55, 104 });
	jump.PushBack({ 176, 805, 50, 89 });
	jump.PushBack({ 251, 798, 54, 77 });
	jump.PushBack({ 327, 813, 48, 70 });
	jump.PushBack({ 397, 810, 48, 89 });
	jump.PushBack({ 464, 819, 55, 109 });
	jump.speed = 0.2f;

	// TODO 4: Make ryu walk backwards with the correct animations
}

ModulePlayer::~ModulePlayer()
{}

// Load assets
bool ModulePlayer::Start()
{
	leftEndPoint = position;
	rightEndPoint= position;
	rightEndPoint.x += 500;

	LOG("Loading player textures");
	bool ret = true;
	graphics = App->textures->Load("ryu.png"); // arcade version
	return ret;
}

// Update: draw background
update_status ModulePlayer::Update()
{
	Animation* current_animation = &idle;

	int speed = 1;
	
	if (App->input->keyboard[SDL_SCANCODE_D] == 1)
	{
		current_animation = &forward;
		if(position.x > leftEndPoint.x && position.x < rightEndPoint.x)
			App->render->camera.x -= speed * 3;

		if (position.x <= rightEndPoint.x + 220)
			position.x += speed;
	}
	
	if (App->input->keyboard[SDL_SCANCODE_A] == 1)
	{
		current_animation = &backward;
	if (position.x < rightEndPoint.x &&position.x > leftEndPoint.x)
		{
		App->render->camera.x += speed * 3;
		}
		if(position.x >= leftEndPoint.x - 90)
			position.x -= speed;
	}

	if (App->input->keyboard[SDL_SCANCODE_X] == 1)
	{
		current_animation = &punch;
	}

	if (App->input->keyboard[SDL_SCANCODE_C] == 1)
	{
		current_animation = &kick;
	}

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == 1)
	{
		current_animation = &jump;
		if (position.y > 160)
			position.y -= speed * 3;
	}
	else {
		if (position.y < 220)
			position.y += speed * 3;
	}

	// Draw everything --------------------------------------

	SDL_Rect r = current_animation->GetCurrentFrame();

	App->render->Blit(graphics, position.x, position.y - r.h, &r);

	return UPDATE_CONTINUE;
}