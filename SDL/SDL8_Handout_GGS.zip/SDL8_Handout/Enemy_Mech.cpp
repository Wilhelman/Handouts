#include "Application.h"
#include "Enemy_Mech.h"
#include "ModuleCollision.h"

Enemy_Mech::Enemy_Mech(int x, int y) : Enemy(x, y)
{
	left.PushBack({ 72,105,28,32 });
	left.PushBack({ 37,108,32,29 });
	left.PushBack({ 37,108,32,29 });
	left.speed = 0.2f;

	right.PushBack({ 106,105,28,32 });
	right.PushBack({ 139,108,32,29 });
	right.PushBack({ 172,108,32,29 });
	right.speed = 0.2f;


	collider = App->collision->AddCollider({ 0, 0, 32, 29 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

	path.PushBack({ 0.5f,0.0f }, 50, &right);
	path.PushBack({ -0.5f,0.0f }, 50, &left);
	path.loop = true;
}

void Enemy_Mech::Move()
{
	position = original_pos + path.GetCurrentPosition(&animation);
	position.x += 1 * SCREEN_SIZE;
}
