#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleFadeToBlack.h"
#include "ModuleSceneSpace.h"
#include "ModuleInput.h"
#include "ModuleIntro.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModuleIntro::ModuleIntro()
{}

ModuleIntro::~ModuleIntro()
{}

// Load assets
bool ModuleIntro::Start()
{
	LOG("Loading space scene");

	background = App->textures->Load("rtype/intro.png");

	return true;
}

// UnLoad assets
bool ModuleIntro::CleanUp()
{
	LOG("Unloading ModuleIntro");

	App->textures->Unload(background);

	return true;
}

// Update: draw background
update_status ModuleIntro::Update()
{
	if (App->input->keyboard[SDL_SCANCODE_RETURN]) {
		App->fade->FadeToBlack(this, App->scene_space);
	}

	// Draw everything --------------------------------------
	App->render->Blit(background, 0, 0, NULL);

	return UPDATE_CONTINUE;
}