#ifndef __ModuleRenderer_H__
#define __ModuleRenderer_H__

struct SDL_Renderer;
struct SDL_Window;
// TODO 1: Create the declaration of ModuleWindow class
class ModuleRenderer : public Module
{

public:
	SDL_Renderer* renderer;

public:

	bool Init(SDL_Window& window);
	update_status PreUpdate();
	update_status Update();
	update_status PostUpdate();
	bool CleanUp();
};


#endif // __ModuleRenderer_H__