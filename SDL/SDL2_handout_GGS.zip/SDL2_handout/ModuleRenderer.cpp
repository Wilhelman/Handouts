#include "Globals.h"
#include "Application.h"
#include "ModuleRenderer.h"
#include "SDL/include/SDL.h"

bool ModuleRenderer::Init(SDL_Window& window) {
	renderer = nullptr;
	renderer = SDL_CreateRenderer(&window, -1, SDL_RENDERER_ACCELERATED);
	if (renderer == nullptr) {
		LOG("Could not create the render: %s\n", SDL_GetError());
		return false;
	}
	return true;
}

update_status ModuleRenderer::PreUpdate() {
	if (SDL_SetRenderDrawColor(renderer, 100, 255, 50, 255) != 0) {
		LOG("Setting render draw color did fail\n");
		return update_status::UPDATE_ERROR;
	}
	else
		return update_status::UPDATE_CONTINUE;
}

update_status ModuleRenderer::Update() {
	if (SDL_RenderClear(renderer) != 0) {
		LOG("RenderClear did fail\n");
		return update_status::UPDATE_ERROR;
	}
	else
		return update_status::UPDATE_CONTINUE;
}

update_status ModuleRenderer::PostUpdate() {
	SDL_RenderPresent(renderer);
	return update_status::UPDATE_CONTINUE;
}

bool ModuleRenderer::CleanUp() {
	SDL_DestroyRenderer(renderer);
	return true;
}